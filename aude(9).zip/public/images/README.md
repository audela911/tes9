# Instructions pour les images

Ce dossier est destiné à contenir toutes les images du site.

Pour que le site s'affiche correctement, veuillez glisser-déposer vos images ici en respectant **exactement** les noms de fichiers suivants :

-   `hero-background.jpg` (Image principale, format portrait 2:3, ex: 1200x1800px)
-   `philippe-portrait.jpg` (Votre portrait, format carré 1:1, ex: 800x800px)

**Pour une performance optimale (recommandé) :**

-   Ajoutez également une version `hero-background.webp` de votre image principale. Les outils en ligne comme Squoosh ou TinyPNG peuvent convertir votre JPG en WebP facilement. Le site chargera cette version plus légère pour les navigateurs compatibles, accélérant l'affichage pour la majorité de vos visiteurs.

Une fois les fichiers ajoutés, le site les affichera automatiquement. Il n'y a aucune modification de code à faire.