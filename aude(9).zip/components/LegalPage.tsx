
import React from 'react';

interface LegalPageProps {
  onNavigate: () => void;
}

const LegalPage: React.FC<LegalPageProps> = ({ onNavigate }) => {
  return (
    <div className="bg-[#0c0a1a] text-gray-300 min-h-screen antialiased">
      <header className="bg-[#0c0a1a]/80 backdrop-blur-md sticky top-0 z-50 transition-all duration-300 shadow-lg shadow-purple-900/10">
        <div className="container mx-auto px-6 py-4 relative flex justify-between items-center">
          <h1 className="text-3xl font-bold text-amber-400 font-esoteric tracking-wider [text-shadow:0_0_10px_rgba(251,191,36,0.6)]">
            Mentions Légales
          </h1>
          <button
            onClick={onNavigate}
            className="bg-transparent border-2 border-gray-600 text-gray-300 font-bold py-2 px-6 text-sm rounded-full hover:border-amber-400 hover:text-amber-300 transition-all duration-300 transform hover:scale-105"
            aria-label="Retour à la page d'accueil"
          >
            &larr; Retour
          </button>
        </div>
      </header>

      <main role="main" className="container mx-auto px-6 py-16">
        <div className="max-w-4xl mx-auto space-y-10 bg-[#110e24]/60 p-8 md:p-12 rounded-2xl shadow-2xl shadow-purple-900/30 border border-purple-800/50 backdrop-blur-sm">
          
          <section aria-labelledby="editor-heading">
            <h2 id="editor-heading" className="text-2xl font-semibold text-amber-300 mb-4 border-l-4 border-amber-400 pl-4">1. Éditeur du site</h2>
            <div className="space-y-2 pl-6">
                <p><strong>Nom commercial :</strong> Au-Delà des Arcanes</p>
                <p><strong>Dirigeant :</strong> tarorworld sa</p>
                <p><strong>Statut :</strong> Entrepreneur Individuel</p>
                <p><strong>SIRET :</strong> 442 395 448 0005</p>
                <p><strong>Adresse du siège :</strong> Entreprise domiciliée à Paris (17). Adresse complète sur demande.</p>
                <p><strong>Email :</strong> <a href="mailto:contact@audeladesarcane.com" className="text-purple-300 hover:underline">contact@audeladesarcane.com</a></p>
                <p><strong>Directeur de la publication :</strong> webnodemaster irland</p>
            </div>
          </section>

          <section aria-labelledby="hosting-heading">
            <h2 id="hosting-heading" className="text-2xl font-semibold text-amber-300 mb-4 border-l-4 border-amber-400 pl-4">2. Hébergement</h2>
            <div className="space-y-6 pl-6">
                <div>
                    <p className="font-semibold text-gray-200">Hébergeur principal :</p>
                    <p><strong>Nom :</strong> Vercel Inc.</p>
                    <p><strong>Adresse :</strong> 340 S Lemon Ave #4133, Walnut, CA 91789, USA</p>
                    <p><strong>Contact :</strong> <a href="https://vercel.com/contact" target="_blank" rel="noopener noreferrer" className="text-purple-300 hover:underline">https://vercel.com/contact</a></p>
                </div>
                <div>
                    <p className="font-semibold text-gray-200">Hébergeur secondaire :</p>
                    <p><strong>Nom :</strong> Netlify, Inc.</p>
                    <p><strong>Adresse :</strong> 44 Montgomery Street, Suite 300, San Francisco, CA 94104, USA</p>
                    <p><strong>Contact :</strong> <a href="https://www.netlify.com/support/" target="_blank" rel="noopener noreferrer" className="text-purple-300 hover:underline">https://www.netlify.com/support/</a></p>
                </div>
            </div>
          </section>

          <section aria-labelledby="ip-heading">
            <h2 id="ip-heading" className="text-2xl font-semibold text-amber-300 mb-4 border-l-4 border-amber-400 pl-4">3. Propriété Intellectuelle</h2>
            <p className="pl-6">L'ensemble de ce site, y compris sa structure, ses textes, ses images et ses logos, constitue une œuvre protégée par les lois en vigueur sur la propriété intellectuelle. Toute reproduction, représentation, modification ou exploitation, même partielle, est strictement interdite sans l'autorisation écrite et préalable de webnodemaster irland.</p>
          </section>
          
          <section aria-labelledby="liability-heading">
            <h2 id="liability-heading" className="text-2xl font-semibold text-amber-300 mb-4 border-l-4 border-amber-400 pl-4">4. Limitation de responsabilité</h2>
            <p className="pl-6">Les consultations de tarot proposées sur ce site sont des prestations de guidance et de développement personnel. Elles ne se substituent en aucun cas à un avis médical, psychologique, juridique ou financier. Chaque consultant reste seul maître de ses décisions et actions. Au-Delà des Arcanes ne saurait être tenu responsable des conséquences des choix personnels du consultant.</p>
          </section>

          <section aria-labelledby="data-heading">
            <h2 id="data-heading" className="text-2xl font-semibold text-amber-300 mb-4 border-l-4 border-amber-400 pl-4">5. Données Personnelles et Confidentialité</h2>
            <p className="pl-6">La confidentialité des consultations est absolue. Aucune information personnelle n'est collectée sur ce site, à l'exception de celles nécessaires à la prise de rendez-vous via la plateforme externe TidyCal. Pour toute information concernant la gestion de vos données par ce service, veuillez consulter leur politique de confidentialité. Conformément au RGPD, vous disposez d'un droit d'accès et de rectification de vos données en contactant directement webnodemaster irland.</p>
          </section>

          <section aria-labelledby="disclaimer-heading">
            <h2 id="disclaimer-heading" className="text-2xl font-semibold text-amber-300 mb-4 border-l-4 border-amber-400 pl-4">6. Avertissement</h2>
            <p className="pl-6">La pratique de la voyance et du tarot est un art et non une science exacte. Les tirages sont basés sur des interprétations symboliques et ne garantissent pas la réalisation des événements évoqués. L'objectif est de fournir des pistes de réflexion et des clés de compréhension, et non des certitudes ou des prédictions infaillibles.</p>
          </section>

        </div>
      </main>
    </div>
  );
};

export default LegalPage;
