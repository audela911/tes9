import React, { memo } from 'react';
import HeartIcon from '@/components/icons/HeartIcon';
import MapIcon from '@/components/icons/MapIcon';
import ChartBarIcon from '@/components/icons/ChartBarIcon';
import StarIcon from '@/components/icons/StarIcon';
import LightningBoltIcon from '@/components/icons/LightningBoltIcon';
import MastercardIcon from '@/components/icons/MastercardIcon';
import PayPalIcon from '@/components/icons/PayPalIcon';

const PaymentIcons: React.FC = () => (
    <div className="flex justify-center items-center gap-4 mt-6 opacity-90">
      <MastercardIcon className="h-6" />
      <PayPalIcon className="h-6" />
    </div>
);

interface ServiceCardProps {
  icon: React.ReactNode;
  title: string;
  description: string;
  duration: string;
  themes: string;
  price?: string;
  buttonText: string;
  bookingUrl: string;
}

const ServiceCard: React.FC<ServiceCardProps> = ({ icon, title, description, duration, themes, price, buttonText, bookingUrl }) => {
    const buttonClass = "block w-full bg-amber-500 text-slate-900 font-bold py-2 px-6 rounded-full hover:bg-amber-400 transition-all duration-300 transform hover:scale-105 shadow-lg shadow-amber-500/40 text-center text-sm animate-pulse-glow border-2 border-amber-300/80";
    
    return (
      <article className="bg-[#1e193b]/70 p-8 rounded-xl shadow-2xl shadow-purple-900/20 border border-purple-800/50 hover:border-amber-400/50 hover:scale-105 transition-all duration-300 flex flex-col hover:shadow-2xl hover:shadow-amber-500/30">
        <div className="flex justify-center text-amber-400 mb-3 animate-key-glow">{icon}</div>
        <h3 className="text-2xl font-semibold mb-4 text-white text-center">{title}</h3>
        <p className="text-gray-400 mb-4 flex-grow">{description}</p>
        <div className="border-t border-purple-800/50 pt-4 text-sm text-gray-300">
            <div className="flex justify-between items-center">
                <p><span className="font-semibold text-amber-300">Durée :</span> {duration}</p>
                {price && <p className="text-xl font-bold text-white">{price}</p>}
            </div>
          <p className="mt-2"><span className="font-semibold text-amber-300">Thèmes :</span> {themes}</p>
        </div>
        <div className="mt-6">
            <a 
                href={bookingUrl}
                target="_blank"
                rel="noopener noreferrer"
                className={buttonClass}
            >
                {buttonText}
            </a>
            <PaymentIcons />
        </div>
      </article>
    );
};

const MemoizedServiceCard = memo(ServiceCard);

const Services: React.FC<{ onNavigate: (sectionId: string, serviceId?: string) => void }> = ({ onNavigate }) => {
  const services = [
    {
      id: "amour",
      icon: <HeartIcon />,
      title: "Voyance Amour",
      description: "Le cœur a ses raisons que la raison ignore... Le tarot lève le voile sur vos doutes, ravive la flamme ou vous aide à guérir pour accueillir l'amour véritable.",
      duration: "45 min",
      price: "40€",
      themes: "Clarté, guérison, avenir sentimental.",
      buttonText: "Révéler mon avenir amoureux",
      bookingUrl: "https://tidycal.com/philippedancel/amour",
    },
    {
      id: "travail",
      icon: <MapIcon />,
      title: "Voyance Travail",
      description: "Votre carrière est à un tournant ? Que vous cherchiez la reconnaissance, un nouveau départ ou l'alignement avec votre mission de vie, les arcanes vous montrent la voie du succès.",
      duration: "45 min",
      price: "40€",
      themes: "Évolution, reconversion, épanouissement.",
      buttonText: "Booster ma carrière",
      bookingUrl: "https://tidycal.com/philippedancel/travail",
    },
    {
      id: "affaires",
      icon: <ChartBarIcon />,
      title: "Voyance Affaires",
      description: "Lancez vos projets avec confiance. Le tarot devient votre conseiller stratégique, éclairant les risques, confirmant les potentiels et sécurisant vos investissements pour une croissance sereine.",
      duration: "45 min",
      price: "40€",
      themes: "Investissements, croissance, confiance.",
      buttonText: "Sécuriser mes projets",
      bookingUrl: "https://tidycal.com/philippedancel/amour-1g8wgv6",
    },
    {
      id: "sans-question",
      icon: <StarIcon />,
      title: "Voyance sans Question",
      description: "Parfois, le message le plus important est celui qu'on n'attend pas. Ce tirage est une conversation ouverte avec votre âme, révélant ce que vous avez besoin de savoir, ici et maintenant.",
      duration: "45 min",
      price: "40€",
      themes: "Développement personnel, potentiels.",
      buttonText: "Recevoir mon message",
      bookingUrl: "https://tidycal.com/philippedancel/amour-1g8wgv6-1w85g8r",
    },
  ];

  return (
    <section id="services" className="py-20">
      <div className="container mx-auto px-6">
        <h2 className="text-4xl font-bold text-center mb-12 text-amber-300">Des Réponses pour Chaque Étape de Votre Vie</h2>
        
        <div className="text-center mb-16 bg-gradient-to-br from-amber-500/20 to-purple-900/20 border-2 border-amber-400 rounded-2xl p-8 max-w-4xl mx-auto shadow-2xl shadow-amber-500/20 transform hover:scale-105 transition-transform duration-300">
          <div className="grid grid-cols-1 md:grid-cols-3 items-center gap-6">
            <div className="text-amber-300 flex-shrink-0 mx-auto md:mx-0">
              <LightningBoltIcon className="h-20 w-20 animate-key-glow" />
            </div>
            <div className="md:text-left md:col-span-2">
              <h3 className="text-3xl font-semibold text-amber-300 mb-2">Offre Spéciale : Question Flash</h3>
              <p className="text-lg text-gray-300 mb-3">Une question précise, une réponse directe. Obtenez un éclaircissement rapide et fiable sur une préoccupation spécifique pour avancer sans douter.</p>
              <div className="flex flex-col sm:flex-row items-center justify-center md:justify-start gap-8 mt-4">
                <div className="text-center sm:text-left">
                    <p className="text-4xl font-bold text-white">15€</p>
                    <p className="text-amber-300 text-sm font-semibold">Durée : 10-15 min</p>
                </div>
                <div className="text-center">
                    <a 
                        href="https://tidycal.com/philippedancel/15-minute-meeting"
                        target="_blank"
                        rel="noopener noreferrer"
                        className="block text-center bg-amber-500 text-slate-900 font-bold py-3 px-8 rounded-full hover:bg-amber-400 transition-all duration-300 transform hover:scale-105 shadow-lg shadow-amber-500/30 animate-pulse-glow border-2 border-transparent"
                        aria-label="Réserver la consultation Question Flash à 15€"
                    >
                        Réserver ma Question Flash
                    </a>
                    <PaymentIcons />
                </div>
              </div>
            </div>
          </div>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
          {services.map((service) => (
            <MemoizedServiceCard key={service.id} {...service} />
          ))}
        </div>
        
        <div className="text-center mt-20">
            <div className="bg-gradient-to-r from-purple-900/50 to-amber-500/30 inline-block p-1 rounded-xl shadow-lg hover:shadow-amber-400/30 transition-shadow duration-300">
                <div className="bg-[#110e24] rounded-lg px-8 py-10 max-w-3xl mx-auto">
                    <h3 className="text-3xl font-bold text-amber-300 mb-4">Prêt(e) à éclairer votre avenir ?</h3>
                    <p className="text-lg text-gray-300 mb-6 max-w-xl mx-auto">
                        N'attendez plus que les doutes s'installent. Offrez-vous la clarté que vous méritez pour avancer avec confiance et sérénité.
                    </p>
                    <p className="text-amber-200 italic text-sm mb-8">
                        Rejoignez les 90+ clients satisfaits qui ont trouvé des réponses.
                    </p>
                    <a
                        href="https://tidycal.com/philippedancel"
                        target="_blank"
                        rel="noopener noreferrer"
                        className="text-center bg-amber-500 text-slate-900 font-bold py-3 px-8 rounded-full hover:bg-amber-400 transition-all duration-300 transform hover:scale-105 shadow-lg shadow-amber-500/30 animate-pulse-glow border-2 border-transparent"
                        aria-label="Voir toutes les disponibilités et réserver une consultation de tarot"
                    >
                        Voir les disponibilités
                    </a>
                    <PaymentIcons />
                </div>
            </div>
        </div>
      </div>
    </section>
  );
};

export default Services;
