import React, { useState, useEffect, useRef, memo } from 'react';
import InstagramIcon from '@/components/icons/InstagramIcon';
import FacebookIcon from '@/components/icons/FacebookIcon';
import YouTubeIcon from '@/components/icons/YouTubeIcon';
import OdyseeIcon from '@/components/icons/OdyseeIcon';

interface HeaderProps {
  onNavigate: (sectionId: string) => void;
}

const Header: React.FC<HeaderProps> = ({ onNavigate }) => {
  const [isOpen, setIsOpen] = useState(false);
  const [activeLink, setActiveLink] = useState('#accueil');
  const [isScrolled, setIsScrolled] = useState(false);
  const observer = useRef<IntersectionObserver | null>(null);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 10);
    };
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  useEffect(() => {
    const sections = document.querySelectorAll('section[id]');
    
    observer.current = new IntersectionObserver((entries) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          setActiveLink(`#${entry.target.id}`);
        }
      });
    }, { rootMargin: '-40% 0px -60% 0px' });

    sections.forEach(section => {
      if(section) observer.current?.observe(section);
    });

    return () => {
      sections.forEach(section => {
        if(section) observer.current?.unobserve(section);
      });
    };
  }, []);
  
  // Effect to lock body scroll when mobile menu is open
  useEffect(() => {
    if (isOpen) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = 'auto';
    }
    // Cleanup function
    return () => {
      document.body.style.overflow = 'auto';
    };
  }, [isOpen]);

  const navLinks = [
    { href: '#accueil', text: 'Accueil' },
    { href: '#a-propos', text: 'À Propos' },
    { href: '#services', text: 'Services' },
    { href: '#faq', text: 'FAQ' },
  ];

  return (
    <header className="bg-[#0c0a1a]/80 backdrop-blur-md sticky top-0 z-50 transition-all duration-300 shadow-lg shadow-purple-900/10">
      <div className="container mx-auto px-6 py-3 relative">
        <div className="flex items-center justify-between">
          <a href="#accueil" onClick={(e) => { e.preventDefault(); onNavigate('#accueil'); }} className="text-3xl font-bold text-amber-400 font-esoteric tracking-wider [text-shadow:0_0_10px_rgba(251,191,36,0.6)]">
            Au-Delà des Arcanes
          </a>
          <nav role="navigation" aria-label="Navigation principale" className="hidden md:flex items-center space-x-2">
            {navLinks.map((link) => {
              const isActive = activeLink === link.href;

              return (
                <a
                  key={link.href}
                  href={link.href}
                  onClick={(e) => {
                    e.preventDefault();
                    onNavigate(link.href);
                  }}
                  className={`py-2 px-4 rounded-full text-sm font-medium transition-all duration-300 ${isActive ? 'bg-purple-800/60 text-amber-300 shadow-inner shadow-purple-900/50' : 'text-gray-300 hover:bg-purple-800/50 hover:text-white'}`}
                >
                  {link.text}
                </a>
              );
            })}
             <a 
                href="https://tidycal.com/philippedancel"
                target="_blank"
                rel="noopener noreferrer"
                className="bg-gradient-to-r from-amber-500 to-yellow-400 text-slate-900 font-bold py-2 px-5 rounded-full hover:from-amber-400 hover:to-yellow-300 transition-all duration-300 transform hover:scale-105 shadow-lg shadow-amber-500/40 hover:shadow-xl hover:shadow-amber-500/60 text-sm animate-pulse-glow border-2 border-transparent"
             >
                Réservation
            </a>
             <span className="text-gray-500 mx-2">|</span>
            <div className="flex items-center space-x-4">
              <a href="https://instagram.com/audeladesarcanes" target="_blank" rel="noopener noreferrer" aria-label="Instagram" className="text-gray-400 hover:text-amber-300 transition-colors">
                <InstagramIcon className="w-5 h-5" />
              </a>
              <a href="https://www.facebook.com/profile.php?id=61581052334003&locale=fr_FR" target="_blank" rel="noopener noreferrer" aria-label="Facebook" className="text-gray-400 hover:text-amber-300 transition-colors">
                <FacebookIcon className="w-5 h-5" />
              </a>
              <a href="https://www.youtube.com/@Lautre-h4c" target="_blank" rel="noopener noreferrer" aria-label="YouTube" className="text-gray-400 hover:text-amber-300 transition-colors">
                <YouTubeIcon className="w-5 h-5" />
              </a>
              <a href="https://odysee.com/@audeladesarcanes" target="_blank" rel="noopener noreferrer" aria-label="Odysee" className="text-gray-400 hover:text-amber-300 transition-colors">
                <OdyseeIcon className="w-5 h-5" />
              </a>
            </div>
          </nav>
          <div className="md:hidden">
            <button
              onClick={() => setIsOpen(!isOpen)}
              className="text-gray-300 focus:outline-none z-50 relative"
              aria-label="Toggle menu"
              aria-expanded={isOpen}
            >
              <svg
                className="w-6 h-6"
                fill="none"
                stroke="currentColor"
                viewBox="0 0 24 24"
                xmlns="http://www.w3.org/2000/svg"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth="2"
                  d={isOpen ? 'M6 18L18 6M6 6l12 12' : 'M4 6h16M4 12h16m-7 6h7'}
                ></path>
              </svg>
            </button>
          </div>
        </div>
        
        {/* Animated Gradient Border */}
        <div 
          className={`absolute bottom-0 left-0 w-full h-px transition-opacity duration-500 ${isScrolled ? 'opacity-100' : 'opacity-0'}`}
          style={{
            background: 'linear-gradient(90deg, transparent, #fbbf24, #a855f7, #fbbf24, transparent)',
            backgroundSize: '200% auto',
            animation: 'animate-gradient-border 4s linear infinite',
          }}
        ></div>

        <div className={`absolute top-full left-0 w-full md:hidden transition-all duration-300 ease-in-out ${isOpen ? 'opacity-100 visible' : 'opacity-0 invisible'}`}>
          <nav role="navigation" aria-label="Navigation mobile" className="bg-[#0c0a1a]/95 backdrop-blur-md p-6 shadow-xl shadow-purple-900/20">
            <ul className="flex flex-col items-center space-y-3">
              {navLinks.map((link) => {
                const isActive = activeLink === link.href;

                return (
                  <li key={link.href} className="w-full">
                    <a
                      href={link.href}
                      onClick={(e) => {
                        e.preventDefault();
                        onNavigate(link.href);
                        setIsOpen(false);
                      }}
                      className={`block w-full text-center py-3 px-5 rounded-full font-medium transition-all duration-300 ${
                        isActive 
                            ? 'bg-purple-800/60 text-amber-300' 
                            : 'text-gray-300 hover:bg-purple-800/50 hover:text-white'
                      }`}
                    >
                      {link.text}
                    </a>
                  </li>
                );
              })}
              <li className="w-full">
                <a 
                    href="https://tidycal.com/philippedancel"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="block w-full text-center py-3 px-5 rounded-full font-medium transition-all duration-300 bg-gradient-to-r from-amber-500 to-yellow-400 text-slate-900 shadow-lg shadow-amber-500/40 animate-pulse-glow border-2 border-transparent"
                >
                    Réservation
                </a>
              </li>
               <li className="w-full pt-4 mt-2 border-t border-purple-800/50">
                <div className="flex justify-center items-center space-x-6">
                  <a href="https://instagram.com/audeladesarcanes" target="_blank" rel="noopener noreferrer" aria-label="Instagram" className="text-gray-400 hover:text-amber-300 transition-colors p-2">
                    <InstagramIcon className="w-6 h-6" />
                  </a>
                  <a href="https://www.facebook.com/profile.php?id=61581052334003&locale=fr_FR" target="_blank" rel="noopener noreferrer" aria-label="Facebook" className="text-gray-400 hover:text-amber-300 transition-colors p-2">
                    <FacebookIcon className="w-6 h-6" />
                  </a>
                  <a href="https://www.youtube.com/@Lautre-h4c" target="_blank" rel="noopener noreferrer" aria-label="YouTube" className="text-gray-400 hover:text-amber-300 transition-colors p-2">
                    <YouTubeIcon className="w-6 h-6" />
                  </a>
                  <a href="https://odysee.com/@audeladesarcanes" target="_blank" rel="noopener noreferrer" aria-label="Odysee" className="text-gray-400 hover:text-amber-300 transition-colors p-2">
                    <OdyseeIcon className="w-6 h-6" />
                  </a>
                </div>
              </li>
            </ul>
          </nav>
        </div>
      </div>
    </header>
  );
};

export default memo(Header);
