import React from 'react';

const Booking: React.FC = () => {
  return (
    <section id="reservation" className="py-20 bg-[#110e24]">
      <div className="container mx-auto px-6">
        <div className="text-center max-w-2xl mx-auto">
            <h2 className="text-4xl font-bold text-amber-300">Réservez Votre Consultation</h2>
            <p className="mt-4 text-lg text-gray-400">
                Franchissez le pas vers la clarté. Sélectionnez simplement le service désiré et un créneau horaire qui vous convient dans mon agenda. Le processus est simple, rapide et entièrement sécurisé.
            </p>
        </div>

        <div className="mt-12 max-w-2xl mx-auto bg-[#1e193b]/50 p-4 sm:p-6 rounded-2xl shadow-2xl shadow-purple-900/30 border border-purple-800/50">
            {/* Wrapper to hide TidyCal branding */}
            <div style={{
                height: '580px',
                overflow: 'hidden',
                borderRadius: '1rem' /* Match parent's rounded-2xl */
            }}>
                <iframe
                    style={{
                        width: '100%',
                        height: '645px', // Taller to push branding out of view
                        border: '0',
                    }}
                    src="https://tidycal.com/philippedancel"
                    frameBorder="0"
                    allow="payment"
                    title="Calendrier de réservation pour une consultation de tarot"
                ></iframe>
            </div>
        </div>
      </div>
    </section>
  );
};

export default Booking;