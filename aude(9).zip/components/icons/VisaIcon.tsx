import React from 'react';

const VisaIcon: React.FC<{ className?: string }> = ({ className }) => (
  <svg className={className} viewBox="0 0 38 12" xmlns="http://www.w3.org/2000/svg" role="img" aria-label="Visa">
    <path d="M10.1 0L6.3 11.8H3.8L0 0h2.7l2.1 8.7L7.3 0z" fill="#1434CB"/>
    <path d="M20.9 0h-2.9c-.8 0-1.4.3-1.7.9l-4.5 10.7h2.8l.9-2.4h3.7l.5 2.4h2.5L20.9 0zm-2.9 6.7l1.3-4 1.3 4h-2.6z" fill="#1434CB"/>
    <path d="M28.1 3.5c.6-.5 1-.8 1.8-.8.6 0 1 .2 1 .7 0 .5-.2.8-.9.9-.4.2-.9.3-1.4.3h-.7v7.4h-2.5V0h3.3c1.3 0 2.2.3 2.8 1 .5.6.8 1.4.8 2.3 0 1-.3 1.8-.9 2.4l3.2 5.9H32l-2.9-5.5z" fill="#1434CB"/>
    <path d="M38 0l-3.8 11.6h-2.6l2.3-7.5c.2-.6.3-1.1.4-1.7h-.1c-.1.5-.2 1-.4 1.7l-1.3 4.1-1.3-4.1c-.1-.7-.2-1.2-.4-1.7h2.8c.1.6.2 1.1.4 1.7L38 0z" fill="#F9A522"/>
  </svg>
);

export default VisaIcon;