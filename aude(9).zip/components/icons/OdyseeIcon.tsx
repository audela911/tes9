import React from 'react';

const OdyseeIcon: React.FC<{ className?: string }> = ({ className }) => (
  <svg
    xmlns="http://www.w3.org/2000/svg"
    className={className || "h-6 w-6"}
    fill="currentColor"
    viewBox="0 0 24 24"
    role="img"
    aria-label="Odysee Logo"
  >
    <path d="M11.999 1.998c-5.52 0-10 4.48-10 10s4.48 10 10 10 10-4.48 10-10-4.48-10-10-10zm-.96 13.34c-.29.4-.8.56-1.28.4-.48-.17-.78-.63-.78-1.14v-5.2c0-.51.3-.97.78-1.14.48-.16 1 .01 1.28.4l2.52 3.44c.2.27.2.66 0 .93l-2.52 3.31z" />
  </svg>
);

export default OdyseeIcon;