import React from 'react';

const MastercardIcon: React.FC<{ className?: string }> = ({ className }) => (
  <svg className={className} viewBox="0 0 32 20" xmlns="http://www.w3.org/2000/svg" role="img" aria-label="Mastercard">
    <circle cx="10" cy="10" r="10" fill="#EB001B"/>
    <circle cx="22" cy="10" r="10" fill="#F79E1B" fillOpacity="0.8"/>
  </svg>
);

export default MastercardIcon;