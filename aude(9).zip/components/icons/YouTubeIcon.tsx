import React from 'react';

const YouTubeIcon: React.FC<{ className?: string }> = ({ className }) => (
  <svg
    xmlns="http://www.w3.org/2000/svg"
    className={className || "h-6 w-6"}
    fill="none"
    viewBox="0 0 24 24"
    stroke="currentColor"
    strokeWidth={1.5}
  >
    <path strokeLinecap="round" strokeLinejoin="round" d="M21.2,8.1c-0.3-1.1-1.2-2.1-2.3-2.4C17.6,5.3,12,5.3,12,5.3s-5.6,0-6.9,0.4C4,6,3.1,7,2.8,8.1C2.5,9.4,2.5,12,2.5,12s0,2.6,0.3,3.9c0.3,1.1,1.2,2.1,2.3,2.4C6.4,18.7,12,18.7,12,18.7s5.6,0,6.9-0.4c1.1-0.3,2.1-1.2,2.4-2.3c0.3-1.3,0.3-3.9,0.3-3.9S21.5,9.4,21.2,8.1z"></path>
    <polygon strokeLinecap="round" strokeLinejoin="round" points="10,14.7 15,12 10,9.3"></polygon>
  </svg>
);

export default YouTubeIcon;