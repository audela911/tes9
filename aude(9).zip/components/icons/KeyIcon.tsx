import React from 'react';

const KeyIcon: React.FC<{ className?: string }> = ({ className }) => (
  <svg 
    xmlns="http://www.w3.org/2000/svg" 
    className={className} 
    viewBox="0 0 100 50"
    aria-hidden="true"
  >
    <defs>
      <linearGradient id="antique-gold" x1="0%" y1="0%" x2="100%" y2="100%">
        <stop offset="0%" stopColor="#FDEEBE" />
        <stop offset="50%" stopColor="#D9A443" />
        <stop offset="100%" stopColor="#A96623" />
      </linearGradient>
    </defs>
    <g fill="url(#antique-gold)" stroke="url(#antique-gold)" strokeWidth="0.75" strokeLinecap="round" strokeLinejoin="round">
      {/* Head of key */}
      <circle cx="82" cy="18.5" r="8" />
      <circle cx="82" cy="31.5" r="8" />
      <circle cx="92" cy="25" r="8" />
      {/* Small knobs on head */}
      <circle cx="75" cy="12" r="1.5" />
      <circle cx="75" cy="38" r="1.5" />
      <circle cx="99.5" cy="25" r="1.5" />
      
      {/* Decorative ball */}
      <circle cx="68" cy="25" r="4.5" />
      
      {/* Shaft */}
      <rect x="5" y="22.5" width="65" height="5" rx="1" />
      
      {/* Teeth */}
      <path d="M 5 22.5 L 5 12 L 9 12 L 9 22.5 Z" />
      <path d="M 12 22.5 L 12 14 C 12 11, 16 11, 16 14 L 16 22.5 Z" />
      <path d="M 19 22.5 L 19 12 L 23 12 L 23 22.5 Z" />
    </g>
  </svg>
);

export default KeyIcon;
