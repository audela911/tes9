import React from 'react';

const ChatBubbleIcon: React.FC<{ className?: string }> = ({ className }) => (
  <svg xmlns="http://www.w3.org/2000/svg" className={className || "h-5 w-5"} fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.5}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M20.25 8.511c.884.284 1.5 1.128 1.5 2.097v4.286c0 1.136-.847 2.1-1.98 2.193l-2.758.275c-.716.071-1.456-.094-2.052-.43M7.5 10.5c0-1.136.847-2.1 1.98-2.193l2.758-.275c.716-.071 1.456.094 2.052.43m-4.205 0a2.57 2.57 0 01-2.57-2.57v-4.286c0-1.136.847-2.1 1.98-2.193l2.758-.275c.716-.071 1.456.094 2.052.43M7.5 10.5v4.286c0 1.136.847 2.1 1.98 2.193l2.758.275c.716.071 1.456-.094 2.052-.43" />
  </svg>
);

export default ChatBubbleIcon;
