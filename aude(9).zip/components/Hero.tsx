import React from 'react';
import EyeIcon from '@/components/icons/EyeIcon';
import StarIcon from '@/components/icons/StarIcon';
import MoonIcon from '@/components/icons/MoonIcon';
import KeyIcon from '@/components/icons/KeyIcon';

interface HeroProps {
  onNavigate: (sectionId: string, serviceId?: string) => void;
}

const Hero: React.FC<HeroProps> = ({ onNavigate }) => {

  return (
    <section id="accueil" className="relative bg-[#0c0a1a] text-white overflow-hidden min-h-screen flex items-center py-24 sm:py-32 lg:py-0">
      <div className="container mx-auto px-6">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          {/* Left Column - Text content */}
          <div className="relative z-10 text-center">
            <div className="flex flex-col items-center gap-4 justify-center">
              <EyeIcon className="h-20 w-20 text-purple-300 animate-eye-glow" />
              <h1 className="text-6xl md:text-7xl font-bold font-esoteric tracking-wider bg-clip-text text-transparent bg-gradient-to-br from-amber-300 to-yellow-500 animate-text-glow">
                Au-Delà des Arcanes
              </h1>
            </div>
            <p className="text-lg text-gray-400 mt-2">
              Des réponses claires pour un avenir serein.
            </p>

            <h2 className="text-4xl sm:text-5xl lg:text-6xl font-bold mt-6 text-white leading-tight animate-fade-in-up" style={{ animationDelay: '200ms', opacity: 0 }}>
              Révélez votre chemin intérieur, avancez avec confiance.
            </h2>

            <p className="mt-6 text-gray-300 max-w-xl mx-auto animate-fade-in-up" style={{ animationDelay: '400ms', opacity: 0 }}>
              Le tarot est plus qu'une prédiction : c'est un dialogue avec votre intuition. Je vous accompagne pour éclairer votre chemin, comprendre vos blocages et prendre des décisions alignées avec votre âme.
            </p>

            <div className="flex flex-col sm:flex-row gap-6 mt-8 animate-fade-in-up" style={{ animationDelay: '600ms', opacity: 0 }}>
              <div className="flex items-center gap-4 bg-white/5 p-4 rounded-lg border border-white/10 flex-1">
                <StarIcon className="h-8 w-8 text-violet-300 flex-shrink-0" />
                <div className="text-left">
                  <p className="font-semibold text-white">Tarologue & Conférencier</p>
                  <p className="text-sm text-gray-400">Approche moderne et bienveillante</p>
                </div>
              </div>
              <div className="flex items-center gap-4 bg-white/5 p-4 rounded-lg border border-white/10 flex-1">
                <MoonIcon className="h-8 w-8 text-violet-300 flex-shrink-0" />
                <div className="text-left">
                  <p className="font-semibold text-white">Disponible 7j/7</p>
                  <p className="text-sm text-gray-400">Consultations de 9h à 22h</p>
                </div>
              </div>
            </div>

            <div className="flex flex-col sm:flex-row gap-4 mt-8 justify-center animate-fade-in-up" style={{ animationDelay: '800ms', opacity: 0 }}>
              <button 
                onClick={() => onNavigate('#services')}
                className="bg-amber-500 text-slate-900 font-bold py-4 px-8 rounded-full hover:bg-amber-400 transition-all duration-300 transform hover:scale-105 shadow-xl shadow-amber-500/40 text-lg hover:shadow-2xl hover:shadow-amber-500/60 text-center animate-pulse-glow border-2 border-amber-300"
              >
                Éclairer mon avenir
              </button>
              <button 
                onClick={() => onNavigate('#services')}
                className="bg-transparent border-2 border-gray-600 text-gray-300 font-bold py-4 px-8 text-lg rounded-full hover:border-amber-400 hover:text-amber-300 transition-all duration-300 transform hover:scale-105 text-center hover:shadow-lg hover:shadow-amber-400/30"
              >
                Découvrir les Services
              </button>
            </div>
          </div>

          {/* Right Column - Image */}
          <div className="relative hidden lg:flex justify-center items-center h-[600px]">
            <div className="absolute w-[400px] h-[550px] bg-violet-900/50 rounded-full blur-3xl"></div>
            <div className="relative w-[400px] h-[600px] rounded-2xl overflow-hidden shadow-2xl shadow-violet-900/50">
                <picture>
                    <source srcSet="/images/hero-background.webp" type="image/webp" />
                    <source srcSet="/images/hero-background.jpg" type="image/jpeg" />
                    <img 
                        src="/images/hero-background.jpg"
                        alt="Main tenant des cartes de tarot sur un fond cosmique illustrant l'intuition"
                        className="absolute inset-0 w-full h-full object-cover"
                        fetchPriority="high"
                        decoding="async"
                        width="1200"
                        height="1800"
                    />
                </picture>
                <div className="absolute inset-0 bg-gradient-to-t from-[#0c0a1a] via-transparent to-transparent opacity-80"></div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Hero;
