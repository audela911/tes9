import React, { useState, memo } from 'react';

const FAQ: React.FC = () => {
  const [openIndex, setOpenIndex] = useState<number | null>(null);

  const handleToggle = (index: number) => {
    setOpenIndex(openIndex === index ? null : index);
  };

  const faqData = [
    {
      question: "Quelle est votre approche du tarot ?",
      answer: "Je considère le tarot comme un outil de développement personnel, pas comme un instrument de prédiction fataliste. Mon rôle est de vous aider à comprendre les énergies en jeu dans votre vie pour que vous puissiez prendre des décisions éclairées. Le libre arbitre est toujours au centre de ma pratique.",
    },
    {
      question: "Comment se déroule une consultation en ligne ?",
      answer: "Après avoir réservé, vous recevrez un lien pour notre session (généralement sur Zoom ou Google Meet). Nous commencerons par un échange pour cerner votre situation. Ensuite, je réaliserai le tirage en direct, en partageant mon écran si vous le souhaitez, et nous interpréterons les messages des cartes ensemble. C'est un dialogue bienveillant et confidentiel.",
    },
    {
      question: "Dois-je préparer quelque chose avant la séance ?",
      answer: "Venez simplement avec un esprit ouvert. Si vous avez une question, essayez de la formuler clairement. Si vous n'en avez pas, ce n'est pas un problème ; le tirage général (Guidance de l'Âme) est parfait pour recevoir le message que vous avez besoin d'entendre maintenant.",
    },
    {
      question: "La confidentialité de notre échange est-elle garantie ?",
      answer: "Absolument. La confidentialité est la base d'une relation de confiance. Tout ce qui est dit pendant nos séances reste strictement entre nous. Je m'engage à respecter une éthique professionnelle rigoureuse.",
    },
    {
      question: "Le paiement en ligne est-il sécurisé ?",
      answer: "Oui, absolument. Toutes les transactions sont gérées via TidyCal, qui utilise Stripe, l'une des plateformes de paiement les plus sécurisées au monde. Vos informations bancaires sont cryptées et ne transitent jamais par mon site. Vous pouvez réserver en toute confiance.",
    },
    {
      question: "Quels moyens de paiement acceptez-vous ?",
      answer: "Vous pouvez régler votre consultation par carte bancaire (Visa, Mastercard, etc.) ou via PayPal. Le choix vous sera proposé au moment de la réservation sur la plateforme sécurisée.",
    },
    {
      question: "Le tarot peut-il vraiment prédire l'avenir ?",
      answer: "Le tarot révèle des tendances et des futurs potentiels basés sur votre situation actuelle. Il vous montre une 'carte routière' des chemins qui s'offrent à vous. Il ne dicte pas un destin immuable, mais vous donne plutôt les clés pour choisir la direction qui vous convient le mieux.",
    },
    {
      question: "Proposez-vous des consultations sur des sujets de santé ?",
      answer: "Non. Le tarot ne doit jamais remplacer un avis médical professionnel. Mes consultations portent sur le développement personnel, sentimental et professionnel. Pour toute question de santé, veuillez consulter un médecin.",
    },
  ];
  
  const faqSchema = {
    "@context": "https://schema.org",
    "@type": "FAQPage",
    "mainEntity": faqData.map(item => ({
      "@type": "Question",
      "name": item.question,
      "acceptedAnswer": {
        "@type": "Answer",
        "text": item.answer
      }
    }))
  };

  return (
    <section id="faq" className="py-20 bg-[#0c0a1a]">
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(faqSchema) }}
      />
      <div className="container mx-auto px-6">
        <h2 className="text-4xl font-bold text-center mb-12 text-amber-300">Vos Questions, Mes Réponses</h2>
        <div className="max-w-3xl mx-auto bg-[#1e193b]/70 rounded-xl shadow-2xl shadow-purple-900/20 border border-purple-800/50">
          {faqData.map((item, index) => (
            <div key={index} className="border-b border-purple-800/50 last:border-b-0 px-8">
              <button
                onClick={() => handleToggle(index)}
                className={`flex justify-between items-center w-full py-5 text-left text-lg font-medium transition-colors duration-300 focus:outline-none ${openIndex === index ? 'text-amber-300' : 'text-gray-200 hover:text-amber-300'}`}
                aria-expanded={openIndex === index}
                aria-controls={`faq-answer-${index}`}
              >
                <span>{item.question}</span>
                <span className={`transform transition-transform duration-300 ${openIndex === index ? 'rotate-180' : 'rotate-0'}`}>
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
                  </svg>
                </span>
              </button>
              <div
                id={`faq-answer-${index}`}
                role="region"
                className={`grid overflow-hidden transition-all duration-500 ease-in-out ${
                  openIndex === index ? 'grid-rows-[1fr] opacity-100' : 'grid-rows-[0fr] opacity-0'
                }`}
              >
                <div className="overflow-hidden">
                  <p className="pb-5 pr-4 text-gray-400">
                    {item.answer}
                  </p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default memo(FAQ);