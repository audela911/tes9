import React, { useState, useEffect, useRef } from 'react';
import QuoteIcon from '@/components/icons/QuoteIcon';

interface Testimonial {
  avatarSeed: string;
  quote: string;
  cite: string;
  gender: 'male' | 'female';
}

const allTestimonials: Testimonial[] = [
    { avatarSeed: 'marie', quote: "Une consultation bluffante de justesse. Philippe a mis des mots précis sur mes blocages amoureux et m'a donné des clés concrètes. Je me sens plus sereine.", cite: '– Marie D., 34 ans', gender: 'female' },
    { avatarSeed: 'julien', quote: "J'avais besoin de clarté sur ma carrière. Le tirage m'a confirmé mes intuitions et donné l'élan pour me lancer. Une aide précieuse.", cite: '– Julien L., Entrepreneur', gender: 'male' },
    { avatarSeed: 'chloe', quote: "Philippe est d'une bienveillance et d'une écoute rares. Sa guidance m'a permis de voir ma situation sous un nouvel angle et de retrouver confiance.", cite: '– Chloé T., 42 ans', gender: 'female' },
    { avatarSeed: 'alexandre', quote: "En tant que chef d'entreprise, je consulte Philippe pour des décisions stratégiques. Son approche pragmatique du tarot est un véritable atout.", cite: '– Alexandre V., Dirigeant', gender: 'male' },
    { avatarSeed: 'sophie', quote: "La séance 'sans question' a été une révélation. J'ai compris ce qui bloquait mon énergie créative. Un grand merci !", cite: '– Sophie M., Artiste', gender: 'female' },
    { avatarSeed: 'marc', quote: "J'étais sceptique, mais la précision de l'analyse m'a convaincu. Une approche moderne et décomplexée du tarot, loin des clichés.", cite: '– Marc F., 55 ans', gender: 'male' },
];


const About: React.FC = () => {
  const [displayedTestimonials, setDisplayedTestimonials] = useState<Testimonial[]>([]);
  const testimonialsRef = useRef<(HTMLQuoteElement | null)[]>([]);

  // Select random testimonials on component mount
  useEffect(() => {
    const shuffled = [...allTestimonials].sort(() => 0.5 - Math.random());
    setDisplayedTestimonials(shuffled.slice(0, 3)); // Display 3 random testimonials
  }, []);

  // Handle intersection observer for fade-in animation
  useEffect(() => {
    // Reset refs array for the new set of testimonials
    testimonialsRef.current = testimonialsRef.current.slice(0, displayedTestimonials.length);
    
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add('is-visible');
            observer.unobserve(entry.target);
          }
        });
      },
      {
        threshold: 0.1,
      }
    );

    const currentRefs = testimonialsRef.current;
    currentRefs.forEach((el) => {
      if (el) {
        observer.observe(el);
      }
    });

    return () => {
      currentRefs.forEach((el) => {
        if (el) {
          observer.unobserve(el);
        }
      });
    };
  }, [displayedTestimonials]);

  return (
    <section id="a-propos" className="py-20 bg-[#110e24] relative overflow-hidden">
        {/* Background Glows */}
        <div className="absolute -top-1/4 -left-1/4 w-1/2 h-full bg-purple-900/30 rounded-full blur-3xl opacity-40 animate-pulse" style={{ animationDuration: '8s' }}></div>
        <div className="absolute -bottom-1/4 -right-1/4 w-1/2 h-full bg-amber-900/20 rounded-full blur-3xl opacity-40 animate-pulse" style={{ animationDuration: '10s' }}></div>
  
      <div className="container mx-auto px-6 relative z-10">
        <div className="text-center mb-16">
          <h2 className="text-4xl sm:text-5xl font-bold text-amber-300 inline-block px-4 relative">
            <span className="absolute top-1/2 left-0 w-16 h-px bg-gradient-to-l from-amber-400/50 to-transparent -translate-y-1/2"></span>
            Votre Tarologue
            <span className="absolute top-1/2 right-0 w-16 h-px bg-gradient-to-r from-amber-400/50 to-transparent -translate-y-1/2"></span>
          </h2>
          <p className="text-xl text-purple-300 mt-4 italic">Consultation intuitive, honnête et bienveillante</p>
        </div>

        <div className="max-w-4xl mx-auto bg-[#1e193b]/50 p-6 md:p-8 rounded-2xl shadow-2xl shadow-purple-900/30 border border-purple-800/50 backdrop-blur-sm">
            <div className="grid md:grid-cols-5 gap-12 items-center">
            <div className="md:col-span-2">
                <div className="p-1.5 bg-gradient-to-br from-amber-500 via-purple-700 to-amber-500 rounded-3xl transform hover:scale-105 transition-transform duration-500 shadow-lg hover:shadow-amber-400/30">
                <img 
                    src="/images/philippe-portrait.jpg" 
                    alt="Portrait de Philippe, tarologue et conférencier" 
                    className="rounded-2xl shadow-lg w-full h-auto object-cover"
                    loading="lazy"
                    decoding="async"
                    width="400"
                    height="400"
                />
                </div>
            </div>
            <div className="md:col-span-3">
                <p className="mb-4 text-lg text-gray-300">
                Je m'appelle Philippe, tarologue et conférencier. Mon parcours m'a enseigné que chaque carte est un miroir, une opportunité de se reconnecter à sa propre sagesse.
                </p>
                <p className="mb-6 text-lg text-gray-300">
                Mon approche est pragmatique et centrée sur vous. L'objectif n'est pas de prédire un futur immuable, mais de vous donner des clés de compréhension pour que vous puissiez prendre des décisions éclairées et avancer avec confiance.
                </p>

                <h3 className="text-2xl font-semibold text-amber-300 mt-10 mb-6 border-l-4 border-amber-400 pl-4">Leurs Histoires, Vos Possibilités</h3>
                <div className="space-y-6">
                  {displayedTestimonials.map((testimonial, index) => (
                    <blockquote
                      key={testimonial.avatarSeed}
                      ref={(el) => { testimonialsRef.current[index] = el; }}
                      className="testimonial-card relative bg-slate-800/40 p-5 rounded-lg pl-10"
                      style={{ transitionDelay: `${index * 150}ms` }}
                    >
                      <QuoteIcon className="absolute top-4 left-3 h-6 w-6 text-amber-500 opacity-50" />
                      <p className="italic text-gray-300">"{testimonial.quote}"</p>
                      <cite className="block text-right mt-2 not-italic text-amber-300">{testimonial.cite}</cite>
                    </blockquote>
                  ))}
                </div>
            </div>
            </div>
        </div>
      </div>
    </section>
  );
};

export default About;
