import React, { memo } from 'react';
import FooterLogoIcon from '@/components/icons/FooterLogoIcon';
import HeartOutlineIcon from '@/components/icons/HeartOutlineIcon';
import EnvelopeIcon from '@/components/icons/EnvelopeIcon';
import PhoneIcon from '@/components/icons/PhoneIcon';
import InstagramIcon from '@/components/icons/InstagramIcon';
import FacebookIcon from '@/components/icons/FacebookIcon';
import YouTubeIcon from '@/components/icons/YouTubeIcon';
import OdyseeIcon from '@/components/icons/OdyseeIcon';

interface FooterProps {
  onNavigate: (sectionId: string, serviceId?: string) => void;
  onNavigateToLegal: () => void;
}

const Footer: React.FC<FooterProps> = ({ onNavigate, onNavigateToLegal }) => {
  const services = [
    { id: 'flash', name: 'Question Flash (15€)', url: 'https://tidycal.com/philippedancel/15-minute-meeting' },
    { id: 'amour', name: 'Voyance Amour', url: 'https://tidycal.com/philippedancel/amour' },
    { id: 'travail', name: 'Voyance Travail', url: 'https://tidycal.com/philippedancel/travail' },
    { id: 'affaires', name: 'Voyance Affaires', url: 'https://tidycal.com/philippedancel/amour-1g8wgv6' },
    { id: 'sans-question', name: 'Voyance sans Question', url: 'https://tidycal.com/philippedancel/amour-1g8wgv6-1w85g8r' },
  ];

  return (
    <footer id="contact" className="bg-[#110e24] text-gray-400 text-sm border-t border-purple-900/50 pt-16 pb-8">
      <div className="container mx-auto px-6">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-12 mb-12">
          {/* Column 1: About */}
          <div className="space-y-4">
            <div className="flex items-center gap-3">
              <FooterLogoIcon className="h-10 w-10 text-purple-400" />
              <div>
                <h3 className="text-2xl font-bold text-amber-300 font-esoteric tracking-wider [text-shadow:0_0_8px_rgba(251,191,36,0.4)]">Au-Delà des Arcanes</h3>
                <p className="text-gray-500">Guidance & Tarot</p>
              </div>
            </div>
            <p>
             Des consultations de tarot éthiques et modernes pour vous apporter clarté, confiance et autonomie. Votre avenir est entre vos mains, le tarot est votre boussole.
            </p>
            <div className="flex items-center gap-2 text-purple-300 font-medium">
              <HeartOutlineIcon className="h-5 w-5" />
              <span>Consultations bienveillantes & confidentielles</span>
            </div>
            <nav aria-label="Réseaux sociaux">
              <div className="flex items-center space-x-4 pt-4">
                <a href="https://instagram.com/audeladesarcanes" target="_blank" rel="noopener noreferrer" aria-label="Instagram" className="text-gray-400 hover:text-amber-300 transition-colors">
                  <InstagramIcon className="w-6 h-6" />
                </a>
                <a href="https://www.facebook.com/profile.php?id=61581052334003&locale=fr_FR" target="_blank" rel="noopener noreferrer" aria-label="Facebook" className="text-gray-400 hover:text-amber-300 transition-colors">
                  <FacebookIcon className="w-6 h-6" />
                </a>
                <a href="https://www.youtube.com/@Lautre-h4c" target="_blank" rel="noopener noreferrer" aria-label="YouTube" className="text-gray-400 hover:text-amber-300 transition-colors">
                  <YouTubeIcon className="w-6 h-6" />
                </a>
                <a href="https://odysee.com/@audeladesarcanes" target="_blank" rel="noopener noreferrer" aria-label="Odysee" className="text-gray-400 hover:text-amber-300 transition-colors">
                  <OdyseeIcon className="w-6 h-6" />
                </a>
              </div>
            </nav>
          </div>

          {/* Column 2: Services */}
          <nav aria-label="Liste des consultations">
            <h4 className="font-bold text-white text-base mb-4">Mes Consultations</h4>
            <ul className="space-y-2">
              {services.map((service) => (
                <li key={service.id}>
                  <a
                    href={service.url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="hover:text-purple-300 transition-colors"
                  >
                    {service.name}
                  </a>
                </li>
              ))}
            </ul>
          </nav>

          {/* Column 3: Contact */}
          <div>
            <h4 className="font-bold text-white text-base mb-4">Contact</h4>
            <ul className="space-y-3">
              <li>
                <p className="font-semibold text-purple-300">Disponible 7j/7</p>
                <p>de 9h à 22h</p>
              </li>
              <li>
                <a
                  href="https://tidycal.com/philippedancel"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="font-bold text-purple-300 hover:text-purple-200 transition-colors inline-flex items-center"
                >
                  Réserver une consultation &rarr;
                </a>
              </li>
            </ul>
          </div>
        </div>

        <hr className="border-purple-800/50 mb-8" />

        <div className="space-y-4 text-xs text-gray-500">
            <div className="flex flex-col md:flex-row justify-between items-center gap-4">
                <p>&copy; {new Date().getFullYear()} Au-Delà des Arcanes. Tous droits réservés.</p>
                <ul className="flex flex-wrap justify-center text-center gap-x-4 gap-y-2 md:text-right">
                    <li>
                      <a 
                        href="#legal" 
                        onClick={(e) => {
                          e.preventDefault();
                          onNavigateToLegal();
                        }}
                        className="hover:text-purple-300 transition-colors"
                      >
                        Mentions Légales
                      </a>
                    </li>
                    <li className="hidden md:block">&bull;</li>
                    <li>Consultations 100% confidentielles</li>
                    <li className="hidden md:block">&bull;</li>
                    <li>Paiement sécurisé</li>
                    <li className="hidden md:block">&bull;</li>
                    <li>Éthique professionnelle</li>
                </ul>
            </div>
            <p>
                <span className="text-purple-400 font-semibold">Mots-clés :</span> voyance tarot en ligne, tarologue professionnel, tirage tarot amour, consultation voyance travail, prédictions affaires, interprétation arcanes, accompagnement personnel, tarot de marseille, voyance par téléphone, voyance par visioconférence.
            </p>
        </div>
      </div>
    </footer>
  );
};

export default memo(Footer);
